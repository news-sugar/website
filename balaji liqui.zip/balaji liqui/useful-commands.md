# Useful Commands for Balaji Liqui Project

## Backend (balaji-backend/)
```
cd balaji-backend
npm install          # Install dependencies
npm start            # Start server (localhost:5000)
npm run dev          # Dev mode with nodemon
```

## Frontend (Static HTML)
```
# Live reload server (install live-server globally first: npm i -g live-server)
live-server          # Serves on localhost:8080

# Python HTTP server (Python 3)
python -m http.server 8000

# VSCode Live Server extension (right-click index.html → Open with Live Server)

# Windows
start index.html     # Open in default browser
```

## Development
```
# Check project structure
tree /F /A          # Windows tree view
dir /s              # List all files

# Backend API test
curl http://localhost:5000/api/quotes -X POST -H "Content-Type: application/json" -d "{\"fullName\":\"Test\"}"

# Linting (if ESLint)
npm run lint

# Git
git status
git add .
git commit -m "Footer social buttons fixed"
git push
```

## File Operations
```
# Edit files with VSCode
code index.html
code styles.css
code scripts.js

# Backup
copy index.html index-backup.html
```

## Network Check
```
netstat -an | findstr :5000   # Check if backend running
taskkill /PID [pid] /F        # Kill process if needed
```

Backend started: `cd balaji-backend && npm start`
