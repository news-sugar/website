# Infra Heading Animation ✓
1. [x] Split text to spans  
2. [x] Add brandFade CSS + keyframes
3. [x] Update TODO
4. [x] Complete

View: `start infrastructure-section.html`
