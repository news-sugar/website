# Infra Escalator Animation ✓
1. [x] CSS keyframes + stagger delays (25s infinite translateY/opacity)
2. [x] JS trigger after entrance stagger
3. [x] Complete

Infinite escalator: boxes flow top-bottom endlessly.

Demo: `start infrastructure-section.html`
