# Get Quote Popup Modal

✅ **COMPLETELY IMPLEMENTED**

- [x] HTML: Modal + buttons ready
- [x] CSS: Full modern styling + animations
- [x] JS: Open/close, validation, File System Access API → saves/appends `quotes.json` with timestamp
- [x] Responsive + accessible (Esc, focus management)

**Usage**:
1. Click "Get Quote" (header or floating btn)
2. Fill form → Submit
3. Browser prompts to save `quotes.json` (first time), then auto-appends

**Features**:
- Required field validation
- Email/phone regex
- JSON array format: `[{fullName, company, phone, email, requirement, timestamp}, ...]`

Tested & ready!

