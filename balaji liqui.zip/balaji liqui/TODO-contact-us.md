# TODO-contact-us.md

## Steps Completed:
- [x] Apply full index.html header, footer, CSS (all <style> blocks), JS (scripts.js + inline)
- [x] Add hero with background image below content
- [x] Remove front image
- [x] Increase hero container vertically, center Contact heading/paragraph

## Status
All changes complete. contact-us.html now matches mainpage exact dimensions, CSS, JS structure.

**Ready to use** 🎉
